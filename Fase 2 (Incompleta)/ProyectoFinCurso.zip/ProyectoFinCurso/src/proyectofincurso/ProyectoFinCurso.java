
package proyectofincurso;

import Modelo.*;
import proyectofincurso.*;
import Controlador.*;
import java.io.InputStreamReader;
import java.sql.*;


public class ProyectoFinCurso {

    public static void main(String[] args) {
            
        // Pantalla inicial
        JF_Administrador vista_Adm = new JF_Administrador();
        vista_Adm.setVisible(true);
        vista_Adm.setLocationRelativeTo(null);
        
    }

}
